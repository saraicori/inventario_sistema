// validacion de lo escrito
 //Mascara de Telefono
 $("[data-mask-tel]").inputmask("9999 999-99-99");
 //Datemask2 mm/dd/yyyy
 //$("#fnacest").inputmask("dd-mm-yyyy", {"placeholder": "dd-mm-aaaa"});

/*iCheck for checkbox and radio inputs
$('input[type="checkbox"].flat-red, input[type="radio"].flat-red').iCheck({
	checkboxClass: 'icheckbox_flat-purple',
	radioClass: 'iradio_flat-purple'
});*/


// validacion de campos
$('#form-registro').formValidation({
	 framework: 'bootstrap',
		 err: {
			container: 'tooltip'
		 },
		 row: {
			selector: 'div'
		},
		 /*icon: {
			valid: 'fa fa-check',
			invalid: 'fa fa-times',
			validating: 'fa fa-refresh'
		 },*/
	 excluded: ':disabled',
	 fields: {
		 cedescolar: {
			 validators: {
				 notEmpty: {
					 message: 'La Cedula Escolar es requerida'
				 },
				 regexp: {
					 regexp: /^[VE][0-9]{11}$/i,
					 message: 'Solo puede contener Numeros y Letras Validas'
				 },
				 stringLength: {
					min: 12,
					max: 12,
					message: 'Verifique, La Cedula Escolar debe tener minimo 12 Digitos'
				 },
				 remote: {
					message: 'Esta Cedula YA EXISTE',
					url: 'consultestud',
					data: {
						type: 'cedescolar'
					},
					type: 'POST',
					delay: 1000
				 }
			 }
		 },
		 apellido: {
			 validators: {
				 notEmpty: {
					 message: 'El apellido es requerido'
				 },
				 regexp: {
					 regexp: /^[a-zA-ZáéíóúñÁÉÍÓÚÑ\s]+$/i,
					 message: 'Solo puede contener letras'
				 }
			 }
		 },				 
		 nombre: {
			 validators: {
				 notEmpty: {
					 message: 'El nombre es requerido'
				 },
				 regexp: {
					 regexp: /^[a-zA-ZáéíóúñÁÉÍÓÚÑ\s]+$/i,
					 message: 'Solo puede contener letras'
				 }
			 }
		 },
		 sexoest: {
			 validators: {
				 notEmpty: {
					 message: 'El sexo es requerido'
				 }
			 }
		 },
		 fnacest: {
			 validators: {
				 notEmpty: {
					 message: 'La fecha de nacimiento es requerida y no puede ir vacia'
				 },
				 date: {
					 format: 'DD-MM-YYYY',
					 message: 'La fecha de nacimiento no es valida'
				 }
			 }
		 },
		 lugnacest: {
			 validators: {
				 notEmpty: {
					 message: 'El Lugar de Nacimiento es requerido y no puede ir vacio'
				 },
				 regexp: {
					 regexp: /^[a-zA-ZáéíóúñÁÉÍÓÚÑ\s]+$/i,
					 message: 'Solo puede contener letras'
				 }
			 }
		 },
		 edoest: {
			 validators: {
				 notEmpty: {
					 message: 'Estado de Nacimiento es requerido'
				 },
				 regexp: {
					 regexp: /^[a-zA-ZáéíóúñÁÉÍÓÚÑ\s]+$/i,
					 message: 'Solo puede contener letras'
				 }
			 }
		 },
		 nacest: {
			 validators: {
				 notEmpty: {
					 message: 'Nacionalidad es requerida'
				 },
				 regexp: {
					 regexp: /^[a-zA-ZáéíóúñÁÉÍÓÚÑ\s]+$/i,
					 message: 'Solo puede contener letras'
				 }
			 }
		 },
		 procedest: {
			 validators: {
				 notEmpty: {
					 message: 'La Procedencia es requerida'
				 }
			 }
		 },
		 religionest: {
			 validators: {
				 notEmpty: {
					 message: 'Religion es requerida'
				 },
				 regexp: {
					 regexp: /^[a-zA-ZáéíóúñÁÉÍÓÚÑ\s]+$/i,
					 message: 'Solo puede contener letras'
				 }
			 }
		 },
		 tallacamest: {
			 validators: {
				 notEmpty: {
					 message: 'Talla Camisa es requerida'
				 },
				 regexp: {
					 regexp: /^[a-zA-ZáéíóúñÁÉÍÓÚÑ\s]+$/i,
					 message: 'Solo puede contener letras'
				 }
			 }
		 },
		 tallapanest: {
			 validators: {
				 notEmpty: {
					 message: 'Talla Pantalon es requerida'
				 },
				 digits: {
					 regexp: /^\b\d[0-9]+$/,
					 message: 'Solo puede contener Numeros'
				 }
			 }
		 },
		 pesoest: {
			 validators: {
				 notEmpty: {
					 message: 'Peso es requerido'
				 },
				 digits: {
					 regexp: /^[0-9]+(\,[0-9]{1,2})?/i,
					 message: 'Solo puede contener Numeros'
				 }
			 }
		 },
		 email: {
			 validators: {
				 notEmpty: {
					 message: 'El correo es requerido y no puede ir vacio'
				 },
				 emailAddress: {
					 message: 'El correo electronico no es valido'
				 }
			 }
		 },
		 tlfnocelest: {
			 message: 'El Teléfono Celular Principal no es valido',
			 validators: {
				 notEmpty: {
					 message: 'El teléfono Celular Principal es requerido y no puede ir vacio'
				 },
				 regexp: {
					 regexp: /^\b\d{4}[ ]?\d{3}[-]?\d{2}[-]?\d{2}\b/,
					 message: 'El Teléfono Celular Principal solo puede contener números'
				 }
			 }
		 },
		 tlfnocasest: {
			 message: 'El Teléfono Principal no es valido',
			 validators: {
				 notEmpty: {
					 message: 'El teléfono Principal es requerido y no puede ir vacio'
				 },
				 regexp: {
					 regexp: /^\b\d{4}[ ]?\d{3}[-]?\d{2}[-]?\d{2}\b/,
					 message: 'El Teléfono Principal solo puede contener números'
				 }
			 }
		 },
		 direccionest: {
			 validators: {
				 notEmpty: {
					 message: 'La Direccion es requerida y no puede ir vacia'
				 },
			 }
		 },
		 statusest: {
			 validators: {
				 notEmpty: {
					 message: 'Estatus es requerido y no puede ir vacio'
				 }
			 }
		 },			 
		 cedulama: {
			 validators: {
				 notEmpty: {
					 message: 'La Cedula es requerida'
				 },
				 digits: {
					 regexp: /^\b\d[0-9]+$/,
					 message: 'Solo puede contener Numeros'
				 }
			 }
		 },
		 apellidoma: {
			 validators: {
				 notEmpty: {
					 message: 'El apellido es requerido'
				 },
				 regexp: {
					 regexp: /^[a-zA-ZáéíóúñÁÉÍÓÚÑ\s]+$/i,
					 message: 'Solo puede contener letras'
				 }
			 }
		 },				 
		 nombrema: {
			 validators: {
				 notEmpty: {
					 message: 'El nombre es requerido'
				 },
				 regexp: {
					 regexp: /^[a-zA-ZáéíóúñÁÉÍÓÚÑ\s]+$/i,
					 message: 'Solo puede contener letras'
				 }
			 }
		 },
		 oficioma: {
			 validators: {
				 notEmpty: {
					 message: 'El oficio es requerido'
				 },
				 regexp: {
					 regexp: /^[a-zA-ZáéíóúñÁÉÍÓÚÑ\s]+$/i,
					 message: 'Solo puede contener letras'
				 }
			 }
		 }, 
		 tlfnocelma: {
			 message: 'El Teléfono Celular no es valido',
			 validators: {
				 notEmpty: {
					 message: 'El teléfono Celular es requerido y no puede ir vacio'
				 },
				 regexp: {
					 regexp: /^\b\d{4}[ ]?\d{3}[-]?\d{2}[-]?\d{2}\b/,
					 message: 'El Teléfono Celular solo puede contener números'
				 }
			 }
		 },
		 tlfnocasma: {
			 message: 'El Teléfono Principal no es valido',
			 validators: {
				 notEmpty: {
					 message: 'El teléfono Principal es requerido y no puede ir vacio'
				 },
				 regexp: {
					 regexp: /^\b\d{4}[ ]?\d{3}[-]?\d{2}[-]?\d{2}\b/,
					 message: 'El Teléfono Principal solo puede contener números'
				 }
			 }
		 },
		 direccionma: {
			 validators: {
				 notEmpty: {
					 message: 'La Direccion es requerida y no puede ir vacio'
				 }
			 }
		 },
		 lugtrabma: {
			 validators: {
				 notEmpty: {
					 message: 'Lugar de Trabajo es requerido'
				 },
				 regexp: {
					 regexp: /^[a-zA-ZáéíóúñÁÉÍÓÚÑ\s]+$/i,
					 message: 'Solo puede contener letras'
				 }
			 }
		 },
		 salarioma: {
			 validators: {
				 notEmpty: {
					 message: 'El nombre es requerido'
				 },
				 regexp: {
					 regexp: /^\d[0-9\.\-\s]+$/,
					 message: 'Solo puede contener Numeros'
				 }
			 }
		 },
		 tlfnotrabma: {
			 message: 'El Teléfono Celular no es valido',
			 validators: {
				 notEmpty: {
					 message: 'El teléfono Celular es requerido y no puede ir vacio'
				 },
				 regexp: {
					 regexp: /^\b\d{4}[ ]?\d{3}[-]?\d{2}[-]?\d{2}\b/,
					 message: 'El Teléfono Celular solo puede contener números'
				 }
			 }
		 },
		 retirarmadre: {
			 validators: {
				 notEmpty: {
					 message: 'Permiso es requerido y no puede ir vacio'
				 }
			 }
		 },
		 cedulapa: {
			 validators: {
				 notEmpty: {
					 message: 'La Cedula es requerida'
				 },
				 digits: {
					 regexp: /^\b\d[0-9]+$/,
					 message: 'Solo puede contener Numeros'
				 }
			 }
		 },
		 apellidopa: {
			 validators: {
				 notEmpty: {
					 message: 'El apellido es requerido'
				 },
				 regexp: {
					 regexp: /^[a-zA-ZáéíóúñÁÉÍÓÚÑ\s]+$/i,
					 message: 'Solo puede contener letras'
				 }
			 }
		 },				 
		 nombrepa: {
			 validators: {
				 notEmpty: {
					 message: 'El nombre es requerido'
				 },
				 regexp: {
					 regexp: /^[a-zA-ZáéíóúñÁÉÍÓÚÑ\s]+$/i,
					 message: 'Solo puede contener letras'
				 }
			 }
		 },
		 oficiopa: {
			 validators: {
				 notEmpty: {
					 message: 'El oficio es requerido'
				 },
				 regexp: {
					 regexp: /^[a-zA-ZáéíóúñÁÉÍÓÚÑ\s]+$/i,
					 message: 'Solo puede contener letras'
				 }
			 }
		 },
		 tlfnocelpa: {
			 message: 'El Teléfono Celular no es valido',
			 validators: {
				 notEmpty: {
					 message: 'El teléfono Celular es requerido y no puede ir vacio'
				 },
				 regexp: {
					 regexp: /^\b\d{4}[ ]?\d{3}[-]?\d{2}[-]?\d{2}\b/,
					 message: 'El Teléfono Celular solo puede contener números'
				 }
			 }
		 },
		 tlfnocaspa: {
			 message: 'El Teléfono Principal no es valido',
			 validators: {
				 notEmpty: {
					 message: 'El teléfono Principal es requerido y no puede ir vacio'
				 },
				 regexp: {
					 regexp: /^\b\d{4}[ ]?\d{3}[-]?\d{2}[-]?\d{2}\b/,
					 message: 'El Teléfono Principal solo puede contener números'
				 }
			 }
		 },
		 direccionpa: {
			 validators: {
				 notEmpty: {
					 message: 'La Direccion es requerida y no puede ir vacio'
				 }
			 }
		 },
		 lugtrabpa: {
			 validators: {
				 notEmpty: {
					 message: 'Lugar de Trabajo es requerido'
				 },
				 regexp: {
					 regexp: /^[a-zA-ZáéíóúñÁÉÍÓÚÑ\s]+$/i,
					 message: 'Solo puede contener letras'
				 }
			 }
		 },
		 salariopa: {
			 validators: {
				 notEmpty: {
					 message: 'El nombre es requerido'
				 },
				 regexp: {
					 regexp: /^\d[0-9\.\-\s]+$/,
					 message: 'Solo puede contener Numeros'
				 }
			 }
		 },
		 tlfnotrabpa: {
			 message: 'El Teléfono Celular no es valido',
			 validators: {
				 notEmpty: {
					 message: 'El teléfono Celular es requerido y no puede ir vacio'
				 },
				 regexp: {
					 regexp: /^\b\d{4}[ ]?\d{3}[-]?\d{2}[-]?\d{2}\b/,
					 message: 'El Teléfono Celular solo puede contener números'
				 }
			 }
		 },
		 retirarpadre: {
			 validators: {
				 notEmpty: {
					 message: 'Permiso es requerido y no puede ir vacio'
				 }
			 }
		 },
		 cedularep: {
			 validators: {
				 notEmpty: {
					 message: 'La Cedula es requerida'
				 },
				 digits: {
					 regexp: /^\b\d[0-9]+$/,
					 message: 'Solo puede contener Numeros'
				 }
			 }
		 },
		 apellidorep: {
			 validators: {
				 notEmpty: {
					 message: 'El apellido es requerido'
				 },
				 regexp: {
					 regexp: /^[a-zA-ZáéíóúñÁÉÍÓÚÑ\s]+$/i,
					 message: 'Solo puede contener letras'
				 }
			 }
		 },				 
		 nombrerep: {
			 validators: {
				 notEmpty: {
					 message: 'El nombre es requerido'
				 },
				 regexp: {
					 regexp: /^[a-zA-ZáéíóúñÁÉÍÓÚÑ\s]+$/i,
					 message: 'Solo puede contener letras'
				 }
			 }
		 },
		 oficiorep: {
			 validators: {
				 notEmpty: {
					 message: 'El oficio es requerido'
				 },
				 regexp: {
					 regexp: /^[a-zA-ZáéíóúñÁÉÍÓÚÑ\s]+$/i,
					 message: 'Solo puede contener letras'
				 }
			 }
		 },
		 tlfnocelrep: {
			 message: 'El Teléfono Principal no es valido',
			 validators: {
				 notEmpty: {
					 message: 'El teléfono Principal es requerido y no puede ir vacio'
				 },
				 regexp: {
					 regexp: /^\b\d{4}[ ]?\d{3}[-]?\d{2}[-]?\d{2}\b/,
					 message: 'El Teléfono Principal solo puede contener números'
				 }
			 }
		 },
		 tlfnocasrep: {
			 message: 'El Teléfono Principal no es valido',
			 validators: {
				 notEmpty: {
					 message: 'El teléfono Principal es requerido y no puede ir vacio'
				 },
				 regexp: {
					 regexp: /^\b\d{4}[ ]?\d{3}[-]?\d{2}[-]?\d{2}\b/,
					 message: 'El Teléfono Principal solo puede contener números'
				 }
			 }
		 },
		 direccionrep: {
			 validators: {
				 notEmpty: {
					 message: 'La Direccion es requerida y no puede ir vacia'
				 }
			 }
		 },
		 parentest: {
			 validators: {
				 notEmpty: {
					 message: 'Parentesco es requerido y no puede ir vacia'
				 }
			 }
		 },
		 retirarrep: {
			 validators: {
				 notEmpty: {
					 message: 'Permiso es requerido y no puede ir vacio'
				 }
			 }
		 },
		 juegasolo: {
			 validators: {
				 notEmpty: {
					 message: 'Requerido. No puede ir vacio'
				 }
			 }
		 },
		 juegaotro: {
			 validators: {
				 notEmpty: {
					 message: 'Requerido. No puede ir vacio'
				 }
			 }
		 },
		 compartej: {
			 validators: {
				 notEmpty: {
					 message: 'Requerido. No puede ir vacio'
				 }
			 }
		 },
		 vivefam: {
			 validators: {
				 notEmpty: {
					 message: 'Requerido. No puede ir vacio'
				 }
			 }
		 },
		 sale: {
			 validators: {
				 notEmpty: {
					 message: 'Requerido. No puede ir vacio'
				 }
			 }
		 },
		 jpref: {
			 validators: {
				 notEmpty: {
					 message: 'Requerido. No puede ir vacio'
				 }
			 }
		 },
		 ppref: {
			 validators: {
				 notEmpty: {
					 message: 'Requerido. No puede ir vacio'
				 }
			 }
		 },
		 tipoviv: {
			 validators: {
				 notEmpty: {
					 message: 'Requerido. No puede ir vacio'
				 }
			 }
		 },
		 propviv: {
			 validators: {
				 notEmpty: {
					 message: 'Requerido. No puede ir vacio'
				 }
			 }
		 },
		 techoviv: {
			 validators: {
				 notEmpty: {
					 message: 'Requerido. No puede ir vacio'
				 }
			 }
		 },
		 pisoviv: {
			 validators: {
				 notEmpty: {
					 message: 'Requerido. No puede ir vacio'
				 }
			 }
		 },
		 servivag: {
			 validators: {
				 notEmpty: {
					 message: 'Requerido. No puede ir vacio'
				 }
			 }
		 },
		 servvivga: {
			 validators: {
				 notEmpty: {
					 message: 'Requerido. No puede ir vacio'
				 }
			 }
		 },
		 servvivel: {
			 validators: {
				 notEmpty: {
					 message: 'Requerido. No puede ir vacio'
				 }
			 }
		 },
		 servvival: {
			 validators: {
				 notEmpty: {
					 message: 'Requerido. No puede ir vacio'
				 }
			 }
		 },
		 servvivia: {
			 validators: {
				 notEmpty: {
					 message: 'Requerido. No puede ir vacio'
				 }
			 }
		 },
		 servvivtl: {
			 validators: {
				 notEmpty: {
					 message: 'Requerido. No puede ir vacio'
				 }
			 }
		 },
		 servvivcl: {
			 validators: {
				 notEmpty: {
					 message: 'Requerido. No puede ir vacio'
				 }
			 }
		 },
		 embades: {
			 validators: {
				 notEmpty: {
					 message: 'Requerido. No puede ir vacio'
				 }
			 }
		 },
		 condparto: {
			 validators: {
				 notEmpty: {
					 message: 'Requerido. No puede ir vacio'
				 }
			 }
		 },
		 cianosis: {
			 validators: {
				 notEmpty: {
					 message: 'Requerido. No puede ir vacio'
				 }
			 }
		 },
		 partoh: {
			 validators: {
				 notEmpty: {
					 message: 'Requerido. No puede ir vacio'
				 }
			 }
		 },
		 enfermemb: {
			 validators: {
				 notEmpty: {
					 message: 'Requerido. No puede ir vacio'
				 }
			 }
		 },
		 accidemb: {
			 validators: {
				 notEmpty: {
					 message: 'Requerido. No puede ir vacio'
				 }
			 }
		 },
		 complicparto: {
			 validators: {
				 notEmpty: {
					 message: 'Requerido. No puede ir vacio'
				 }
			 }
		 },
		 convulsion: {
			 validators: {
				 notEmpty: {
					 message: 'Requerido. No puede ir vacio'
				 }
			 }
		 },
		 consultaped: {
			 validators: {
				 notEmpty: {
					 message: 'Requerido. No puede ir vacio'
				 }
			 }
		 },
		 medidanacer: {
			 validators: {
				 notEmpty: {
					 message: 'Requerido. No puede ir vacio'
				 },
				  regexp: {
					 regexp: /^[0-9]+(\,[0-9]{1,2})?/i,
					 message: 'Solo puede contener Numeros'
				 }
			 }
		 },
		 pesonacer: {
			 validators: {
				 notEmpty: {
					 message: 'Requerido. No puede ir vacio'
				 },
				  regexp: {
					 regexp: /^[0-9]+(\,[0-9]{1,2})?/i,
					 message: 'Solo puede contener Numeros'
				 }
			 }
		 },
		 tipoparto: {
			 validators: {
				 notEmpty: {
					 message: 'Requerido. No puede ir vacio'
				 }
			 }
		 },
		 diversid: {
			 validators: {
				 notEmpty: {
					 message: 'Requerido. No puede ir vacio'
				 }
			 }
		 },
		 diversidotro: {
			 validators: {
				 notEmpty: {
					 message: 'Requerido. No puede ir vacio'
				 },
				 regexp: {
					 regexp: /^[a-zA-ZáéíóúñÁÉÍÓÚÑ\s]+$/i,
					 message: 'Solo puede contener letras'
				 }
			 }
		 },
		 asma: {
			 validators: {
				 notEmpty: {
					 message: 'Requerido. No puede ir vacio'
				 }
			 }
		 },
		 alergias: {
			 validators: {
				 notEmpty: {
					 message: 'Requerido. No puede ir vacio'
				 },
			 }
		 },
		 /* alergialim: {
			 validators: {
				 notEmpty: {
					 message: 'Requerido. No puede ir vacio'
				 },
			 }
		 },*/
		 alergialimespec: {
			 validators: {
				 notEmpty: {
					 message: 'Requerido. No puede ir vacio'
				 },
				 regexp: {
					 regexp: /^[a-zA-ZáéíóúñÁÉÍÓÚÑ\s]+$/i,
					 message: 'Solo puede contener letras'
				 }
			 }
		 },
		 /* alergiamed: {
			 validators: {
				 notEmpty: {
					 message: 'Requerido. No puede ir vacio'
				 },
			 }
		 },*/
		 alergiamedespec: {
			 validators: {
				 notEmpty: {
					 message: 'Requerido. No puede ir vacio'
				 },
				 regexp: {
					 regexp: /^[a-zA-ZáéíóúñÁÉÍÓÚÑ\s]+$/i,
					 message: 'Solo puede contener letras'
				 }
			 }
		 },
		 /*alergiaotr: {
			 validators: {
				 notEmpty: {
					 message: 'Requerido. No puede ir vacio'
				 },
			 }
		 },*/
		 alergiaotrespec: {
			 validators: {
				 notEmpty: {
					 message: 'Requerido. No puede ir vacio'
				 },
				 regexp: {
					 regexp: /^[a-zA-ZáéíóúñÁÉÍÓÚÑ\s]+$/i,
					 message: 'Solo puede contener letras'
				 }
			 }
		 },
		 entrat: {
			 validators: {
				 notEmpty: {
					 message: 'Requerido. No puede ir vacio'
				 }
			 }
		 },
		 nombmedico: {
			 validators: {
				 notEmpty: {
					 message: 'Requerido. No puede ir vacio'
				 },
				 regexp: {
					 regexp: /^[a-zA-ZáéíóúñÁÉÍÓÚÑ\s]+$/i,
					 message: 'Solo puede contener letras'
				 }
			 }
		 },
		 edadmad: {
			 validators: {
				 notEmpty: {
					 message: 'Requerido. No puede ir vacio'
				 },
				  digits: {
					 regexp: /^\b\d[0-9]+$/,
					 message: 'Solo puede contener Numeros'
				 }
			 }
		 },
		 edadgatea: {
			 validators: {
				 notEmpty: {
					 message: 'Requerido. No puede ir vacio'
				 },
				  regexp: {
					 regexp: /^[0-9a-zA-ZáéíóúñÁÉÍÓÚÑ\.\s]+$/i,
					 message: 'Solo puede contener Letras y Numeros'
				 }
			 }
		 },
		 edadcam: {
			 validators: {
				 notEmpty: {
					 message: 'Requerido. No puede ir vacio'
				 },
				  regexp: {
					 regexp: /^[0-9a-zA-ZáéíóúñÁÉÍÓÚÑ\.\s]+$/i,
					 message: 'Solo puede contener Letras y Numeros'
				 }
			 }
		 },
		 edadhab: {
			 validators: {
				 notEmpty: {
					 message: 'Requerido. No puede ir vacio'
				 },
				  regexp: {
					 regexp: /^[0-9a-zA-ZáéíóúñÁÉÍÓÚÑ\.\s]+$/i,
					 message: 'Solo puede contener Letras y Numeros'
				 }
			 }
		 },
		 comverb: {
			 validators: {
				 notEmpty: {
					 message: 'Requerido. No puede ir vacio'
				 }
			 }
		 },
		 comgest: {
			 validators: {
				 notEmpty: {
					 message: 'Requerido. No puede ir vacio'
				 }
			 }
		 },
		 comsolo: {
			 validators: {
				 notEmpty: {
					 message: 'Requerido. No puede ir vacio'
				 }
			 }
		 },
		 chupad: {
			 validators: {
				 notEmpty: {
					 message: 'Requerido. No puede ir vacio'
				 }
			 }
		 },
		 esfana: {
			 validators: {
				 notEmpty: {
					 message: 'Requerido. No puede ir vacio'
				 }
			 }
		 },
		 esfuri: {
			 validators: {
				 notEmpty: {
					 message: 'Requerido. No puede ir vacio'
				 }
			 }
		 },
		 duermes: {
			 validators: {
				 notEmpty: {
					 message: 'Requerido. No puede ir vacio'
				 }
			 }
		 },
		 berrin: {
			 validators: {
				 notEmpty: {
					 message: 'Requerido. No puede ir vacio'
				 }
			 }
		 },
		 actberrin: {
			 validators: {
				 notEmpty: {
					 message: 'Requerido. No puede ir vacio'
				 }
			 }
		 },
		 pnac: {
			 validators: {
				 notEmpty: {
					 message: 'Requerido. No puede ir vacio'
				 }
			 }
		 },
		 cirep: {
			 validators: {
				 notEmpty: {
					 message: 'Requerido. No puede ir vacio'
				 }
			 }
		 },
		 exfotest: {
			 validators: {
				 notEmpty: {
					 message: 'Requerido. No puede ir vacio'
				 }
			 }
		 },
		 exfotrep: {
			 validators: {
				 notEmpty: {
					 message: 'Requerido. No puede ir vacio'
				 }
			 }
		 },
		 exctlvac: {
			 validators: {
				 notEmpty: {
					 message: 'Requerido. No puede ir vacio'
				 }
			 }
		 },
		 exinfmed: {
			 validators: {
				 notEmpty: {
					 message: 'Requerido. No puede ir vacio'
				 }
			 }
		 },
		 exorina: {
			 validators: {
				 notEmpty: {
					 message: 'Requerido. No puede ir vacio'
				 }
			 }
		 },
		 exheces: {
			 validators: {
				 notEmpty: {
					 message: 'Requerido. No puede ir vacio'
				 }
			 }
		 },
		 exantitet: {
			 validators: {
				 notEmpty: {
					 message: 'Requerido. No puede ir vacio'
				 }
			 }
		 },
		 exhemat: {
			 validators: {
				 notEmpty: {
					 message: 'Requerido. No puede ir vacio'
				 }
			 }
		 },
		 excardio: {
			 validators: {
				 notEmpty: {
					 message: 'Requerido. No puede ir vacio'
				 }
			 }
		 },
		 exespecotro: {
			 validators: {
				 notEmpty: {
					 message: 'Requerido. No puede ir vacio'
				 },
				 regexp: {
					 regexp: /^[a-zA-ZáéíóúñÁÉÍÓÚÑ\s]+$/i,
					 message: 'Solo puede contener letras'
				 }
			 }
		 },
		 cantherm: {
			 validators: {
				 notEmpty: {
					 message: 'Requerido. No puede ir vacio'
				 },
				  digits: {
					 regexp: /^\b\d[0-9]+$/,
					 message: 'Solo puede contener Numeros'
				 }
			 }
		 },
		 lugher: {
			 validators: {
				 notEmpty: {
					 message: 'Requerido. No puede ir vacio'
				 }
			 }
		 },
		 canthhemb: {
			 validators: {
				 notEmpty: {
					 message: 'Requerido. No puede ir vacio'
				 },
				  digits: {
					 regexp: /^\b\d[0-9]+$/,
					 message: 'Solo puede contener Numeros'
				 }
			 }
		 },
		 canthvar: {
			 validators: {
				 notEmpty: {
					 message: 'Requerido. No puede ir vacio'
				 },
				  digits: {
					 regexp: /^\b\d[0-9]+$/,
					 message: 'Solo puede contener Numeros'
				 }
			 }
		 },
		 viveabu: {
			 validators: {
				 notEmpty: {
					 message: 'Requerido. No puede ir vacio'
				 }
			 }
		 },
		 enguard: {
			 validators: {
				 notEmpty: {
					 message: 'Requerido. No puede ir vacio'
				 }
			 }
		 },
		 herpadre: {
			 validators: {
				 notEmpty: {
					 message: 'Requerido. No puede ir vacio'
				 },
				  digits: {
					 regexp: /^\b\d[0-9]+$/,
					 message: 'Solo puede contener Numeros'
				 }
			 }
		 },
		 hermadre: {
			 validators: {
				 notEmpty: {
					 message: 'Requerido. No puede ir vacio'
				 },
				  digits: {
					 regexp: /^\b\d[0-9]+$/,
					 message: 'Solo puede contener Numeros'
				 }
			 }
		 },
		 hermpayma: {
			 validators: {
				 notEmpty: {
					 message: 'Requerido. No puede ir vacio'
				 }
			 }
		 },
		 vivemad: {
			 validators: {
				 notEmpty: {
					 message: 'Requerido. No puede ir vacio'
				 }
			 }
		 },
		 vivepad: {
			 validators: {
				 notEmpty: {
					 message: 'Requerido. No puede ir vacio'
				 }
			 }
		 },
		 vpadrast: {
			 validators: {
				 notEmpty: {
					 message: 'Requerido. No puede ir vacio'
				 }
			 }
		 },
		 visitpad: {
			 validators: {
				 notEmpty: {
					 message: 'Requerido. No puede ir vacio'
				 }
			 }
		 },
		 cantvisitpad: {
			 validators: {
				 notEmpty: {
					 message: 'Requerido. No puede ir vacio'
				 },
				  digits: {
					 regexp: /^\b\d[0-9]+$/,
					 message: 'Solo puede contener Numeros'
				 }
			 }
		 }
	 }
});
/* esta funcion servira para hacerle el formValidator a los campos de la Cedula.
** Si el usuario ingresa la cedula nacional en el campo cedullaest del estudiante 
** el sistema verificará ese campo y no el de la cedula escolar. El orto caso es el 
** de la cedula escolar, Si se escribe en ese campo el sistema verificará cedula escolar 
** y no la cedula nacional. 
*/
/*}) esta linea se debe cambiar por la ultima de la funcion. sin punto y coma para q continue la rutina del formvalidator
$('#form-registro').data('formValidation').enableFieldValidators('cedulaest', true/false); esta linea debe colocarse para que verifique cual de los dos campos hay q validar
	.on('keyup', '[name="cedescolar"], [name="cedulaest"]', function(e) {
		var cedulaest = $('#form-registro').find('[name="cedulaest"]').val(),
			cedescolar= $('#form-registro').find('[name="cedescolar"]').val(),
			fv        = $('#form-registro').data('formValidation');

		switch ($(this).attr('name')) {
			// User is focusing the cedescolar field
			case 'cedescolar':
				fv.enableFieldValidators('cedulaest', cedescolar === '').revalidateField('cedulaest');

				if (cedescolar && fv.getOptions('cedescolar', null, 'enabled') === false) {
					fv.enableFieldValidators('cedescolar', true).revalidateField('cedescolar');
				} else if (cedescolar === '' && cedulaest !== '') {
					fv.enableFieldValidators('cedescolar', false).revalidateField('cedescolar');
				}
				break;

			// User is focusing the drivers license field
			case 'cedulaest':
				if (cedulaest === '') {
					fv.enableFieldValidators('cedescolar', true).revalidateField('cedescolar');
				} else if (cedescolar === '') {
					fv.enableFieldValidators('cedescolar', false).revalidateField('cedescolar');
				}

				if (cedulaest && cedescolar === '' && fv.getOptions('cedulaest', null, 'enabled') === false) {
					fv.enableFieldValidators('cedulaest', true).revalidateField('cedulaest');
				}
				break;lar

			default:
				break;
		}
	});*/