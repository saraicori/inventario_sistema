// mascara de la fecha
<<<<<<< HEAD
$('#fservicio').inputmask('99-99-9999', {'placeholder': 'dd-mm-aaaa'});
=======
$('#fservicio').inputmask('dd-mm-yyyy', {'placeholder': 'dd-mm-aaaa'});
>>>>>>> b3a9d77ff28af9602d75580ad73c149eb50d2e4a
 //Mascara de Telefono
//$('[data-mask-tel]').inputmask({ regexp: "/^\b\d{(4)}[ ]?\d{3}[-]?\d{2}[-]?\d{2}\b/" });
$('[data-mask-tel]').inputmask('(9999) 999-99-99');
//Date range as a button
$("#fservicio").datepicker({
	isRTL: false,
	format: 'dd-mm-yyyy',
	autoclose:true,
	language:'es',
});

// validacion de campos
$('#form-registro').formValidation({
	 framework: 'bootstrap',
	 err: {
		container: '#msgerrores'
	 },
	 icon: {
		valid: 'fa fa-check',
		invalid: 'fa fa-times',
		validating: 'fa fa-refresh'
	 },
	 excluded: ':disabled',
	 fields: {
		 fservicio: {
			 validators: {
				 notEmpty: {
					 message: 'Fecha de Servicio es requerida'
				 }
			 }
		 },
		 cedcli: {
			 validators: {
				 notEmpty: {
					 message: 'Cedula es requerida'
				 },
				 regexp: {
					 regexp: /^\b\d[0-9]+$/,
					 message: 'Solo puede contener Numeros'
				 }
			 }
		 },
		 nombcli: {
			 validators: {
				 notEmpty: {
					 message: 'Nombre es requerido'
				 },
				 regexp: {
					 regexp: /^[a-zA-ZáéíóúñÁÉÍÓÚÑ.\s]+$/i,
					 message: 'Solo puede contener letras'
				 }
			 }
		 },
		 dircli: {
			 validators: {
				 notEmpty: {
					 message: 'Direccion es requerida'
				 },
				 stringLength: {
					max: 80,
					message: 'Ha llegado al limite de este campo'
				 },
			 }
		 },
		 dirref: {
			 validators: {
				 notEmpty: {
					 message: 'Pto. de Ref. es requerida'
				 },
				 stringLength: {
					max: 80,
					message: 'Ha llegado al limite de este campo'
				 },
			 }
		 },
		 tlfnocasa: {
			 message: 'Nro Celular no es valido',
			 validators: {
				 notEmpty: {
					 message: 'Tlfno Casa es requerido'
				 }
			 }
		 },
		 tlfnocel: {
			 message: 'El Teléfono Celular no es valido',
			 validators: {
				 notEmpty: {
					 message: 'Celular es requerido'
				 }
			 }
		 }
	 }
});
