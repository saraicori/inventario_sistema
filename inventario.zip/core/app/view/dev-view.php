        <section class="content">
<div class="row">
	<div class="col-md-12">
	<h1>Devolucion</h1>
  <p>Escriba el FOLIO de la venta:</p>
	<br>
		<form class="form-horizontal" method="get" id="addcategory" action="./index.php" role="form">
<input type="hidden" name="view" value="devolution">

  <div class="form-group">
    <label for="inputEmail1" class="col-lg-2 control-label">Folio*</label>
    <div class="col-md-6">
      <input type="text" name="id" required class="form-control" id="name" required placeholder="Folio">
    </div>
  </div>

  <div class="form-group">
    <div class="col-lg-offset-2 col-lg-10">
      <button type="submit" class="btn btn-primary">Proceder</button>
    </div>
  </div>
</form>
	</div>
</div>
</section>