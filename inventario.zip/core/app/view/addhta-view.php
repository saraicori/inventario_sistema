<?php
if(count($_POST)>0){
$user = new HtaData();
$mod=$_REQUEST['name'];
$des=$_REQUEST['description'];

$user->add();

//$link =mysqli_connect("localhost","root","");
 //mysqli_select_db($link,"ultima_version_herramientas");
 //$result = mysqli_query($link,"insert into herramientas
//(name,description)
//values ('$mod','$des')");

print "<script>window.location='index.php?view=herramientas';</script>";

?>